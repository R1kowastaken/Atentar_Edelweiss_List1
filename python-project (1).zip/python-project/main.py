# create a list 

items = ["Notebook", "Pen", "Calculator", "Laptop", "Book"]

print("Original List:", items)

index = int(input("Input Index to Update: "))
new = input("Input New Value: ")

items[index] = new

print("Updated List:", items)

start = int(input("Enter Slice Range 1: "))
end = int(input("Enter Slice Range 2: "))

print("Sliced List:", items[start:end])

search = input("Enter Item to Search: ")

if search in items:
    print("Item Found!")
else:
    print("Item Not Found!")

print("Final List:", items)
